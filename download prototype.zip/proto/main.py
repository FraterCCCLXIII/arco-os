"""
Prototype entrypoint.

Usage:
    python main.py examples/tasklist.json task phone
    python main.py examples/habit.json habit watch
    python main.py examples/contact.json contact desktop

This is the whole loop:
  1. load a manifest the system has never specifically been coded for
  2. ask the model to pick+populate a template (constrained JSON output)
  3. validate that output against selection_schema.json -- reject if invalid
  4. render deterministically (no AI past this point)
  5. demonstrate the capability gate blocking/allowing an action

Requires ANTHROPIC_API_KEY in the environment.
"""
import json
import sys
import os
from pathlib import Path
from jsonschema import validate, ValidationError
import anthropic

import capabilities
from renderer import render_page

HERE = Path(__file__).parent


def load_json(path):
    with open(path) as f:
        return json.load(f)


def select_template(manifest, entity_name, device_class, templates, selection_schema, prompt_text):
    client = anthropic.Anthropic()

    allowed_templates = [
        t for t in templates["templates"]
        if t["template_id"] in templates["device_class_defaults"].get(device_class, [])
    ]

    user_payload = {
        "device_class": device_class,
        "entity_name": entity_name,
        "allowed_templates": allowed_templates,
        "manifest_entity": manifest["entities"][entity_name],
        "manifest_actions": [a for a in manifest["actions"] if a["entity"] == entity_name],
    }

    resp = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1000,
        system=prompt_text,
        messages=[{
            "role": "user",
            "content": (
                "Select and populate a template for this input. "
                "Respond with ONLY a JSON object matching the required schema, no other text:\n\n"
                + json.dumps(user_payload, indent=2)
            ),
        }],
    )

    raw_text = "".join(b.text for b in resp.content if b.type == "text").strip()
    # strip accidental code fences
    raw_text = raw_text.removeprefix("```json").removeprefix("```").removesuffix("```").strip()

    try:
        selection = json.loads(raw_text)
    except json.JSONDecodeError as e:
        raise RuntimeError(f"Model did not return valid JSON: {e}\nRaw: {raw_text}")

    try:
        validate(instance=selection, schema=selection_schema)
    except ValidationError as e:
        raise RuntimeError(f"Model output failed schema validation, REJECTED (not rendered): {e.message}")

    # Extra structural check beyond the raw JSON Schema: template must be
    # in the allowed list for this device_class, and mapped fields/actions
    # must actually exist in the manifest. This is the second, independent
    # check -- never trust the model's own claim that it followed the rules.
    valid_ids = {t["template_id"] for t in allowed_templates}
    if selection["template_id"] not in valid_ids:
        raise RuntimeError(f"REJECTED: template_id '{selection['template_id']}' not allowed for device_class '{device_class}'")

    valid_fields = set(manifest["entities"][entity_name]["fields"].keys())
    valid_actions = {a["action_id"] for a in manifest["actions"]}
    for slot, val in selection["slot_mapping"].items():
        values = val if isinstance(val, list) else [val]
        for v in values:
            if v not in valid_fields and v not in valid_actions:
                raise RuntimeError(f"REJECTED: slot '{slot}' references unknown field/action '{v}' not in manifest")

    return selection


def demo_data(entity_name):
    fake = {
        "task": [
            {"title": "Renew passport", "notes": "Expires next month", "due_date": "2026-08-01", "status": "open"},
            {"title": "Finish Iranian-Buddhist synthesis draft", "notes": "", "due_date": "2026-07-10", "status": "in_progress"},
        ],
        "contact": [
            {"full_name": "Dana Reyes", "relationship": "Sister", "phone": "555-0134", "email": "dana@example.com", "medical_notes": "Penicillin allergy"},
        ],
        "habit": [
            {"name": "Meditation", "streak_days": 14, "done_today": False},
        ],
    }
    return fake.get(entity_name, [])


def main():
    if len(sys.argv) != 4:
        print("Usage: python main.py <manifest_path> <entity_name> <device_class>")
        sys.exit(1)

    manifest_path, entity_name, device_class = sys.argv[1:4]

    manifest = load_json(manifest_path)
    templates = load_json(HERE / "templates.json")
    selection_schema = load_json(HERE / "selection_schema.json")
    prompt_text = (HERE / "prompt.md").read_text()

    print(f"--- Selecting template for entity='{entity_name}' device_class='{device_class}' ---")
    selection = select_template(manifest, entity_name, device_class, templates, selection_schema, prompt_text)
    print(json.dumps(selection, indent=2))

    records = demo_data(entity_name)
    html = render_page(
        selection["template_id"],
        selection["slot_mapping"],
        manifest["entities"][entity_name]["fields"],
        records,
        device_class,
    )
    out_path = HERE / "static" / f"{manifest['app_id']}_{device_class}.html"
    out_path.write_text(html)
    print(f"--- Rendered to {out_path} ---")

    # --- Capability gate demo ---
    capabilities.init_db()
    capabilities.grant(f"{manifest['app_id']}:write", "demo_user")

    for action in manifest["actions"]:
        allowed, reason = capabilities.check_action(action, actor="demo_user", confirmed=False)
        print(f"action '{action['action_id']}' (destructive={action.get('destructive', False)}): allowed={allowed} ({reason})")

    print("\nNote: destructive actions were blocked above because 'confirmed' was False. "
          "That's the deterministic gate working as intended, not a bug.")


if __name__ == "__main__":
    main()
