"""
Deterministic template renderer. Takes a validated TemplateSelection
(already checked against selection_schema.json) plus real data records and
produces HTML. The model never touches this step's output directly — it
only supplied the template_id + slot_mapping, both already validated as
referring to real manifest fields/actions.
"""
from html import escape


def render(template_id: str, slot_mapping: dict, entity_fields: dict, records: list[dict], device_class: str) -> str:
    if template_id == "list_view":
        return _render_list(slot_mapping, records)
    if template_id == "detail_card":
        return _render_detail(slot_mapping, entity_fields, records[0] if records else {})
    if template_id == "glance_view":
        return _render_glance(slot_mapping, records[0] if records else {})
    if template_id == "dashboard_tile":
        return _render_tile(slot_mapping, records[0] if records else {})
    if template_id == "tv_focus_list":
        return _render_tv_list(slot_mapping, records)
    if template_id == "form":
        return _render_form(slot_mapping, entity_fields)
    raise ValueError(f"Unknown template_id: {template_id}")


def _render_list(slot_mapping, records):
    title_f = slot_mapping.get("title_field")
    sub_f = slot_mapping.get("subtitle_field")
    items = "".join(
        f'<li class="row"><span class="title">{escape(str(r.get(title_f, "")))}</span>'
        f'<span class="subtitle">{escape(str(r.get(sub_f, "")))}</span></li>'
        for r in records
    )
    return f'<ul class="adaptive list_view">{items}</ul>'


def _render_detail(slot_mapping, entity_fields, record):
    header_f = slot_mapping.get("header_field")
    body_fs = slot_mapping.get("body_fields", [])
    if isinstance(body_fs, str):
        body_fs = [body_fs]
    header = escape(str(record.get(header_f, "")))
    body = "".join(
        f'<div class="field"><label>{escape(entity_fields.get(f, {}).get("label", f))}</label>'
        f'<span>{escape(str(record.get(f, "")))}</span></div>'
        for f in body_fs
    )
    return f'<div class="adaptive detail_card"><h2>{header}</h2>{body}</div>'


def _render_glance(slot_mapping, record):
    primary_f = slot_mapping.get("primary_field")
    val = escape(str(record.get(primary_f, "")))
    return f'<div class="adaptive glance_view"><span class="glance-value">{val}</span></div>'


def _render_tile(slot_mapping, record):
    head_f = slot_mapping.get("headline_field")
    sub_f = slot_mapping.get("sublabel_field")
    return (
        f'<div class="adaptive dashboard_tile">'
        f'<div class="headline">{escape(str(record.get(head_f, "")))}</div>'
        f'<div class="sublabel">{escape(str(record.get(sub_f, "")))}</div></div>'
    )


def _render_tv_list(slot_mapping, records):
    title_f = slot_mapping.get("title_field")
    items = "".join(
        f'<li class="tv-row" tabindex="0">{escape(str(r.get(title_f, "")))}</li>' for r in records
    )
    return f'<ul class="adaptive tv_focus_list">{items}</ul>'


def _render_form(slot_mapping, entity_fields):
    order = slot_mapping.get("field_order", [])
    if isinstance(order, str):
        order = [order]
    inputs = "".join(
        f'<label>{escape(entity_fields.get(f, {}).get("label", f))}'
        f'<input name="{escape(f)}" /></label>'
        for f in order
    )
    return f'<form class="adaptive form">{inputs}<button type="submit">Save</button></form>'


PAGE_SHELL = """<!doctype html>
<html><head><meta charset="utf-8">
<style>
  body {{ font-family: system-ui, sans-serif; margin: 2rem; max-width: 480px; }}
  .adaptive {{ border: 1px solid #ddd; border-radius: 8px; padding: 1rem; }}
  .row {{ display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid #eee; }}
  .glance-value {{ font-size: 2rem; font-weight: 600; }}
  .field {{ margin: 0.5rem 0; }}
  .field label {{ display: block; font-size: 0.8rem; color: #666; }}
  form label {{ display: block; margin: 0.5rem 0; }}
  .device-label {{ color: #888; font-size: 0.8rem; margin-bottom: 1rem; }}
</style></head>
<body>
<div class="device-label">device_class: {device_class} — template: {template_id}</div>
{content}
</body></html>
"""


def render_page(template_id, slot_mapping, entity_fields, records, device_class):
    content = render(template_id, slot_mapping, entity_fields, records, device_class)
    return PAGE_SHELL.format(device_class=device_class, template_id=template_id, content=content)
